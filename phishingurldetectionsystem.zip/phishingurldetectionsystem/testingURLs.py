import pandas as pd
import tensorflow as tf
import numpy as np
import urllib
from urllib.parse import urlparse, urlencode
from tensorflow.keras.layers import Embedding
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.preprocessing.text import one_hot
from tensorflow.keras.layers import LSTM
from tensorflow.keras.layers import Dense

tf.random.set_seed(42)
np.random.seed(42)

model = tf.keras.models.load_model('model.h5')

import nltk
import re
from nltk.corpus import stopwords

from nltk.stem.porter import PorterStemmer
ps = PorterStemmer()  

voc_size = 10000
url = 'https://www.google.com'
# messages = url
messages = urlparse(url).netloc
print(messages)

corpus=[]

review = re.sub('[^a-zA-Z]',' ',messages)
review = review.lower()
review = review.split()
review=' '.join(review)
corpus.append(review)
print(corpus[0])

onehot_repr=[one_hot(words,voc_size)for words in corpus]
print(onehot_repr[0])

sent_length = 50
embedded_docs= pad_sequences(onehot_repr,padding='pre',maxlen=sent_length)
print(embedded_docs[0])

x_test = np.array(embedded_docs)
#y_final  = np.array(y)
print(x_test)

y_pred = model.predict(x_test)
classes_y=np.round(y_pred).astype(int)

print(y_pred)
print(classes_y)
'''
if classes_y == 0:
    print('not a phishing')
else:
    print('phishing')
    '''
